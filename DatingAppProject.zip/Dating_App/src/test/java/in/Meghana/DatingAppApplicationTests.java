package in.Meghana;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class DatingAppApplicationTests {

	@Test
	void contextLoads() {
	}

}
